package com.example.lab_03.bai01_SendInformation;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.lab_03.R;

public class SendInfoActivity extends AppCompatActivity {

    // Khai báo các View
    private EditText etName, etCMND, etExtra;
    private Spinner spDegree;
    private CheckBox cbSport, cbMusic, cbReading;
    private Button btnSend, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai01_activity_send_info);

        // Ánh xạ view
        etName = findViewById(R.id.etName);
        etCMND = findViewById(R.id.etCMND);
        spDegree = findViewById(R.id.spDegree);
        cbSport = findViewById(R.id.cbSport);
        cbMusic = findViewById(R.id.cbMusic);
        cbReading = findViewById(R.id.cbReading);
        etExtra = findViewById(R.id.etExtra);
        btnSend = findViewById(R.id.btnSend);
        btnBack = findViewById(R.id.btnBack);

        // Xử lý nút gửi thông tin
        btnSend.setOnClickListener(v -> {
            if (!validate()) return;

            String name = etName.getText().toString();
            String cmnd = etCMND.getText().toString();
            String degree = spDegree.getSelectedItem().toString();

            StringBuilder hobbies = new StringBuilder();
            if (cbSport.isChecked()) hobbies.append("Thể thao ");
            if (cbMusic.isChecked()) hobbies.append("Âm nhạc ");
            if (cbReading.isChecked()) hobbies.append("Đọc sách ");

            String extra = etExtra.getText().toString();

            // Tạo intent và gửi dữ liệu sang DisplayInfoActivity
            Intent i = new Intent(SendInfoActivity.this, DisplayInfoActivity.class);
            i.putExtra("name", name);
            i.putExtra("cmnd", cmnd);
            i.putExtra("degree", degree);
            i.putExtra("hobbies", hobbies.toString());
            i.putExtra("extra", extra);
            startActivity(i);
        });

        // Xử lý nút quay về màn hình chính
        btnBack.setOnClickListener(v -> finish());
    }

    // Hàm kiểm tra dữ liệu nhập
    private boolean validate() {
        String name = etName.getText().toString().trim();
        String cmnd = etCMND.getText().toString().trim();

        if (name.length() < 3) {
            etName.setError("Tên phải có ít nhất 3 ký tự");
            return false;
        }

        if (!cmnd.matches("\\d{9}")) {
            etCMND.setError("CMND phải gồm đúng 9 chữ số");
            return false;
        }

        if (!cbSport.isChecked() && !cbMusic.isChecked() && !cbReading.isChecked()) {
            Toast.makeText(this, "Chọn ít nhất 1 sở thích!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
