package com.example.lab_03.bai01_SendInformation;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.lab_03.R;

public class DisplayInfoActivity extends AppCompatActivity {

    private TextView tvName, tvCMND, tvDegree, tvHobbies, tvExtra;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai01_activity_display_info);

        // Ánh xạ
        tvName = findViewById(R.id.tvName);
        tvCMND = findViewById(R.id.tvCMND);
        tvDegree = findViewById(R.id.tvDegree);
        tvHobbies = findViewById(R.id.tvHobbies);
        tvExtra = findViewById(R.id.tvExtra);
        btnBack = findViewById(R.id.btnBack);

        // Nhận dữ liệu từ Intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            tvName.setText( extras.getString("name"));
            tvCMND.setText( extras.getString("cmnd"));
            tvDegree.setText( extras.getString("degree"));
            tvHobbies.setText( extras.getString("hobbies"));
            tvExtra.setText( extras.getString("extra"));
        }

        // Nút quay về
        btnBack.setOnClickListener(v -> finish());
    }
}
